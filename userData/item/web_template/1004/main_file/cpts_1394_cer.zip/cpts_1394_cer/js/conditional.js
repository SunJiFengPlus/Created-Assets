Modernizr.load([
  {
    test: Modernizr.mq('only all'),
    nope: 'lib/js/respond.min.js'
  }
]);